pip3 install crypt
pip3 install psycopg2
pip3 install random
pip3 install flask
pip3 install datetime